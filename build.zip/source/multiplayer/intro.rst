Multiplayer games
=================

.. toctree::
    :maxdepth: 2

    groups.rst
    waitpages.rst
    chat.rst
