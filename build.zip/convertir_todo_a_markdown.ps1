# ============================================================
# Script para convertir TODA la documentación HTML a Markdown
# Convierte recursivamente todos los archivos .html a .md
# ============================================================

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host "   CONVERSIÓN COMPLETA: HTML → MARKDOWN" -ForegroundColor Cyan
Write-Host "   Convirtiendo TODOS los archivos..." -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Magenta
Write-Host ""

# Verificar que estamos en el directorio correcto
if (-not (Test-Path "build\html\es")) {
    Write-Host "❌ ERROR: No se encuentra build\html\es\" -ForegroundColor Red
    Write-Host ""
    Write-Host "Primero debes generar el HTML con:" -ForegroundColor Yellow
    Write-Host "  python -m sphinx -b html -D language=es source build\html\es" -ForegroundColor Gray
    Write-Host ""
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Verificar Pandoc
Write-Host "🔍 Verificando Pandoc..." -ForegroundColor Cyan
try {
    $pandocVersion = pandoc --version 2>&1 | Select-Object -First 1
    Write-Host "  ✓ $pandocVersion" -ForegroundColor Green
    Write-Host ""
} catch {
    Write-Host "  ❌ Pandoc no está instalado" -ForegroundColor Red
    Write-Host ""
    Write-Host "Descarga Pandoc desde:" -ForegroundColor Yellow
    Write-Host "  https://github.com/jgm/pandoc/releases/latest" -ForegroundColor Gray
    Write-Host ""
    Write-Host "O instala con Chocolatey:" -ForegroundColor Yellow
    Write-Host "  choco install pandoc" -ForegroundColor Gray
    Write-Host ""
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Limpiar carpeta markdown_es si existe
if (Test-Path "markdown_es") {
    Write-Host "🗑️  Limpiando carpeta anterior..." -ForegroundColor Yellow
    Remove-Item -Recurse -Force "markdown_es"
    Write-Host "  ✓ Carpeta limpiada" -ForegroundColor Green
    Write-Host ""
}

# Crear carpeta principal
New-Item -ItemType Directory -Force -Path "markdown_es" | Out-Null

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "📄 Buscando archivos HTML..." -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Encontrar TODOS los archivos HTML recursivamente
$htmlFiles = Get-ChildItem -Path "build\html\es" -Filter "*.html" -Recurse

Write-Host "  Encontrados: $($htmlFiles.Count) archivos HTML" -ForegroundColor Green
Write-Host ""

Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "🔄 Convirtiendo archivos..." -ForegroundColor Cyan
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$convertidos = 0
$errores = 0

foreach ($htmlFile in $htmlFiles) {
    # Calcular ruta relativa desde build\html\es
    $relativePath = $htmlFile.FullName.Substring((Resolve-Path "build\html\es").Path.Length + 1)
    
    # Crear ruta de salida Markdown
    $mdPath = Join-Path "markdown_es" $relativePath.Replace('.html', '.md')
    
    # Crear subdirectorios si es necesario
    $mdDir = Split-Path -Parent $mdPath
    if ($mdDir -and -not (Test-Path $mdDir)) {
        New-Item -ItemType Directory -Force -Path $mdDir | Out-Null
    }
    
    # Mostrar progreso
    $fileName = $htmlFile.Name
    Write-Host "  [$($convertidos + $errores + 1)/$($htmlFiles.Count)] $relativePath" -ForegroundColor Cyan -NoNewline
    
    try {
        # Convertir con Pandoc
        pandoc $htmlFile.FullName -f html -t markdown --wrap=none -o $mdPath 2>$null
        
        if (Test-Path $mdPath) {
            Write-Host " ✓" -ForegroundColor Green
            $convertidos++
        } else {
            Write-Host " ✗" -ForegroundColor Red
            $errores++
        }
    } catch {
        Write-Host " ✗ Error" -ForegroundColor Red
        $errores++
    }
}

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host "✅ CONVERSIÓN COMPLETADA" -ForegroundColor Green
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor Green
Write-Host ""

# Estadísticas
Write-Host "📊 Estadísticas:" -ForegroundColor Cyan
Write-Host "  └─ Total archivos HTML: $($htmlFiles.Count)" -ForegroundColor White
Write-Host "  └─ Convertidos exitosamente: $convertidos" -ForegroundColor Green
if ($errores -gt 0) {
    Write-Host "  └─ Errores: $errores" -ForegroundColor Red
}
Write-Host ""

# Mostrar estructura de carpetas creadas
Write-Host "📁 Estructura generada:" -ForegroundColor Cyan
$carpetas = Get-ChildItem -Path "markdown_es" -Directory -Recurse | Select-Object -ExpandProperty FullName
if ($carpetas) {
    foreach ($carpeta in $carpetas) {
        $relPath = $carpeta.Substring((Resolve-Path "markdown_es").Path.Length)
        Write-Host "  └─ $relPath\" -ForegroundColor White
    }
}
Write-Host ""

# Contar archivos por carpeta
Write-Host "📈 Archivos por sección:" -ForegroundColor Cyan
$raiz = (Get-ChildItem -Path "markdown_es\*.md" -File).Count
Write-Host "  └─ Raíz: $raiz archivos" -ForegroundColor White

$subdirs = Get-ChildItem -Path "markdown_es" -Directory
foreach ($dir in $subdirs) {
    $count = (Get-ChildItem -Path $dir.FullName -Filter "*.md" -File).Count
    Write-Host "  └─ $($dir.Name): $count archivos" -ForegroundColor White
}
Write-Host ""

# Listar archivos principales en raíz
Write-Host "📄 Archivos principales generados:" -ForegroundColor Cyan
$mainFiles = Get-ChildItem -Path "markdown_es\*.md" -File | Sort-Object Name | Select-Object -First 10
foreach ($file in $mainFiles) {
    $size = [math]::Round($file.Length / 1KB, 1)
    Write-Host "  ✓ $($file.Name) ($size KB)" -ForegroundColor Green
}
if ((Get-ChildItem -Path "markdown_es\*.md" -File).Count -gt 10) {
    $remaining = (Get-ChildItem -Path "markdown_es\*.md" -File).Count - 10
    Write-Host "  ... y $remaining más" -ForegroundColor Gray
}
Write-Host ""

Write-Host "📂 Ubicación:" -ForegroundColor Cyan
Write-Host "  └─ $(Resolve-Path markdown_es)" -ForegroundColor Yellow
Write-Host ""

# Crear índice README
Write-Host "📋 Creando índice README.md..." -ForegroundColor Cyan
$readmeContent = @"
# Documentación de oTree en Español (Markdown)

Documentación completa convertida desde HTML a Markdown.

## 📊 Estadísticas

- **Total de archivos:** $convertidos archivos .md
- **Fecha de generación:** $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
- **Formato:** Markdown (.md)
- **Idioma:** Español

## 📁 Estructura

"@

# Agregar estructura de carpetas al README
$allMdFiles = Get-ChildItem -Path "markdown_es" -Filter "*.md" -Recurse
$groupedFiles = $allMdFiles | Group-Object { Split-Path -Parent $_.FullName }

foreach ($group in $groupedFiles | Sort-Object Name) {
    $folderName = if ($group.Name -match "markdown_es\\(.+)") { 
        $matches[1] 
    } else { 
        "Raíz" 
    }
    
    $readmeContent += "`n`n### $folderName`n`n"
    
    foreach ($file in $group.Group | Sort-Object Name) {
        $fileName = $file.Name
        $relativePath = $file.FullName.Substring((Resolve-Path "markdown_es").Path.Length + 1)
        $readmeContent += "- [$fileName](./$($relativePath.Replace('\', '/')))`n"
    }
}

$readmeContent += @"

## 🚀 Uso

### Para Claude AI
1. Sube los archivos .md relevantes a tu conversación
2. Claude puede responder preguntas usando esta documentación

### Para lectura
- Abre cualquier archivo .md con tu editor favorito
- Compatible con VS Code, Notepad++, etc.

## 🔗 Enlaces

- **Documentación online:** https://otree.readthedocs.io/es/latest/
- **Repositorio:** https://github.com/oTree-org/oTree
- **Sitio web:** https://www.otree.org/

---

Generado automáticamente desde: build\html\es\
"@

$readmeContent | Out-File -FilePath "markdown_es\README.md" -Encoding UTF8
Write-Host "  ✓ README.md creado" -ForegroundColor Green
Write-Host ""

Write-Host "💡 Tips:" -ForegroundColor Yellow
Write-Host "  • Ver todos los archivos: dir markdown_es\*.md -Recurse" -ForegroundColor Gray
Write-Host "  • Abrir un archivo: notepad markdown_es\index.md" -ForegroundColor Gray
Write-Host "  • Ver estructura: tree markdown_es /F" -ForegroundColor Gray
Write-Host ""

# Preguntar si abrir la carpeta
$respuesta = Read-Host "¿Abrir la carpeta markdown_es? (S/N)"
if ($respuesta -eq "S" -or $respuesta -eq "s") {
    explorer "markdown_es"
    Write-Host ""
    Write-Host "✓ Carpeta abierta en el Explorador" -ForegroundColor Green
}

Write-Host ""
Write-Host "Presiona Enter para salir..." -ForegroundColor Gray
Read-Host